local base = require("plugins.configs.lspconfig")
local on_attach = base.on_attach
local capabilities = base.capabilities

local lspconfig = require("lspconfig")

lspconfig.clangd.setup {
  on_attach = function(client, bufnr)
    client.server_capabilities.signatureHelpProvider = false
    on_attach(client, bufnr)
  end,

  capabilities = capabilities,
}

lspconfig.bashls.setup {
  on_attach = on_attach,
  capabilities = capabilities,
  -- flags = {
  --   debounce_text_changes = 150,
  -- },
}

lspconfig.dockerls.setup {
  on_attach = on_attach,
  capabilities = capabilities,
  -- flags = {
  --   debounce_text_changes = 150,
  -- },
}

lspconfig.jsonls.setup {
  on_attach = on_attach,
  capabilities = capabilities,
  -- flags = {
  --   debounce_text_changes = 150,
  -- },
}

lspconfig.yamlls.setup {
  on_attach = on_attach,
  capabilities = capabilities,
  -- flags = {
  --   debounce_text_changes = 150,
  -- },
}

lspconfig.cmake.setup {
  on_attach = on_attach,
  capabilities = capabilities,
}
